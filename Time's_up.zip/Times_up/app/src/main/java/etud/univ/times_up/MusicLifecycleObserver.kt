package etud.univ.times_up

import android.content.Context
import android.content.Intent
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner

class MusicLifecycleObserver(private val context: Context) : LifecycleObserver {

    private var isMusicRunning = false

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun onEnterForeground() {
        if (!isMusicRunning) {
            val musicIntent = Intent(context, BackgroundMusicService::class.java)
            context.startService(musicIntent)
            isMusicRunning = true
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    fun onEnterBackground() {
        val musicIntent = Intent(context, BackgroundMusicService::class.java)
        context.stopService(musicIntent)
        isMusicRunning = false
    }
}