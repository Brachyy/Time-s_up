package etud.univ.times_up
object TeamManager {
    private val teams = mutableListOf<Team>()
    fun addTeam(team: Team) {
        teams.add(team)
    }
    fun getSize():Int{
        return teams.size
    }

    fun removeTeam(position: Int) {
        teams.removeAt(position)
    }
    fun removePlayerFromTeam(team: Team, player: Player) {
        team.players.remove(player)  // Supprime le joueur de l'équipe
    }
    fun addPlayerToTeam(team: Team, playerName: String) {

        team.addPlayer(playerName)  // Ajoute le joueur à l'équipe
    }


    fun getTeams(): MutableList<Team> = teams

    fun clearTeams() {
        teams.clear()
    }
}



