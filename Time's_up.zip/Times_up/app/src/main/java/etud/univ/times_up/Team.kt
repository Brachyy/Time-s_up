package etud.univ.times_up

// Data class Player avec seulement un nom
data class Player(
    val name: String
)

// Data class Team avec une couleur aléatoire et un score
data class Team(
    val name: String,
    val color: Int = listOf(0xFFFF0000.toInt(), 0xFF0000FF.toInt(), 0xFF00FF00.toInt()).random(), // Couleur aléatoire en hex
    val players: MutableList<Player> = mutableListOf(),
    var score: Int = 0
) {

    // Méthode pour ajouter un joueur à l'équipe
    fun addPlayer(playerName: String) {
        players.add(Player(playerName))
    }
    fun removePlayer(playerName: String) {
        players.remove(Player(playerName))
    }

    // Méthode pour ajouter des points au score de l'équipe
    fun addPoints(points: Int) {
        score += points
    }

    // Méthode pour retirer des points au score de l'équipe
    fun removePoints(points: Int) {
        score -= points
    }

    // Méthode pour récupérer la couleur en String (optionnel)
    fun getColorName(): String {
        return when (color) {
            0xFFFF0000.toInt() -> "Red"
            0xFF0000FF.toInt() -> "Blue"
            0xFF00FF00.toInt() -> "Green"
            else -> "Unknown"
        }
    }
}
