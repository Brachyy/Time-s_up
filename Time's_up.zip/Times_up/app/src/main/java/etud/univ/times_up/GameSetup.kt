package etud.univ.times_up

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.drawable.TransitionDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import etud.univ.times_up.databinding.ActivityGameSetupBinding

class GameSetup : AppCompatActivity() {

    private lateinit var binding: ActivityGameSetupBinding
    private val adapter = TeamAdapter(TeamManager.getTeams())  // Utilise TeamManager pour les équipes

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnTouchListener { _, event ->
            val transition = binding.backButton.drawable as TransitionDrawable
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    transition.startTransition(150)
                    playButtonSong(this)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    transition.reverseTransition(150)
                    val intent = Intent(this, StartActivity::class.java)
                    startActivity(intent)
                }
            }
            true
        }
        binding.playGameButton.setOnTouchListener { _, event ->
            val transition = binding.playGameButton.drawable as TransitionDrawable
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    transition.startTransition(150)
                    playButtonSong(this)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    transition.reverseTransition(150)
                    if(checkTeam()){
                        val intent = Intent(this, GameActivity::class.java)
                        startActivity(intent)
                    }
                }
            }
            true
        }





        // RecyclerView setup
        binding.teamsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.teamsRecyclerView.adapter = adapter

        // Gérer le clic sur "Ajouter une équipe"
        binding.addTeamButton.setOnClickListener {
            if (TeamManager.getTeams().size < 4) { // Limite à 4 équipes
                val newTeam = Team("Équipe ${TeamManager.getTeams().size + 1}")
                TeamManager.addTeam(newTeam)  // Ajouter à TeamManager
                adapter.notifyItemInserted(TeamManager.getTeams().size - 1)  // Notifie l'adapter que l'équipe a été ajoutée
            }
        }
    }


    override fun onPause() {
        Log.d("TeamManager", "==== Liste des équipes et joueurs ====")
        logTeamsAndPlayers()
        super.onPause()

    }
    private fun logTeamsAndPlayers() {
        Log.d("TeamManager", "==== Liste des équipes et joueurs ====")
        TeamManager.getTeams().forEach { team ->
            Log.d("TeamManager", "Équipe: ${team.name}, Couleur: ${team.color}, Score: ${team.score}")
            team.players.forEach { player ->
                Log.d("TeamManager", "  Joueur: ${player.name}")
            }
        }
    }
    private fun checkTeam(): Boolean {
        // Vérifie si TeamManager contient des équipes
        if (TeamManager.getTeams().isEmpty()) {
            return false
        }

        // Vérifie si toutes les équipes ont au moins un joueur
        for (team in TeamManager.getTeams()) {
            if (team.players.isEmpty()) {
                return false
            }
        }

        // Si toutes les équipes ont au moins un joueur
        return true
    }
}
