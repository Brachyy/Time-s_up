package etud.univ.times_up

import android.graphics.Color
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import etud.univ.times_up.databinding.ItemTeamBinding
import android.widget.TextView
import android.widget.Button
import android.widget.LinearLayout
import androidx.core.content.ContextCompat

class TeamAdapter(private val teams: List<Team>) : RecyclerView.Adapter<TeamAdapter.TeamViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TeamViewHolder {
        val binding = ItemTeamBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TeamViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TeamViewHolder, position: Int) {
        val team = teams[position]
        holder.bind(team)
    }

    override fun getItemCount(): Int {
        return teams.size
    }

    inner class TeamViewHolder(private val binding: ItemTeamBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(team: Team) {
            binding.teamName.text = team.name

            // Gérer la suppression de l'équipe
            binding.removeTeamButton.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    TeamManager.removeTeam(position)  // Supprime l'équipe de TeamManager
                    notifyItemRemoved(position)  // Notifie l'adapter de la suppression
                }
            }

            // Gérer l'ajout de joueurs
            binding.addPlayerButton.setOnClickListener {
                val playerName = binding.playerNameInput.text.toString().trim()

                if (playerName.isNotEmpty()) {
                    TeamManager.addPlayerToTeam(team, playerName)  // Ajoute le joueur à TeamManager
                    binding.playerNameInput.text.clear()  // Vide le champ de texte
                    notifyItemChanged(adapterPosition)  // Rafraîchit la ligne de l'équipe
                }
            }

            // Afficher la liste des joueurs avec un bouton pour supprimer chaque joueur
            displayPlayers(team)
        }

        private fun displayPlayers(team: Team) {
            binding.playersListContainer.removeAllViews()
            team.players.forEach { player ->
                val playerView = TextView(itemView.context)
                playerView.text = player.name.uppercase()
                val spSize = 10f
                val pxSize = TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_SP,
                    spSize,
                    itemView.context.resources.displayMetrics
                )
                playerView.textSize = pxSize
                playerView.setTextColor(ContextCompat.getColor(itemView.context, R.color.colorPrimary))
                // Créer un bouton de suppression pour chaque joueur
                val removePlayerButton = Button(itemView.context).apply {
                    text = "SUPPRIMER"
                    setOnClickListener {
                        TeamManager.removePlayerFromTeam(team, player)  // Supprime le joueur de TeamManager
                        team.players.remove(player)  // Supprime le joueur de l'équipe localement
                        notifyItemChanged(adapterPosition)  // Rafraîchit la ligne de l'équipe
                    }
                }

                // Ajouter le TextView et le bouton de suppression au layout
                val playerLayout = LinearLayout(itemView.context).apply {
                    orientation = LinearLayout.HORIZONTAL

                    // Pour centrer le joueur à gauche et aligner le bouton à droite
                    val layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    layoutParams.weight = 1f  // Donne du poids au TextView pour qu'il prenne de la place
                    playerView.layoutParams = layoutParams

                    addView(playerView)  // Ajouter le nom du joueur
                    removePlayerButton.layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        gravity = android.view.Gravity.END  // Aligne le bouton à droite
                    }
                    addView(removePlayerButton)  // Ajouter le bouton de suppression
                }

                binding.playersListContainer.addView(playerLayout)  // Ajouter l'élément au conteneur
            }
        }

    }
}

