package etud.univ.times_up

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.drawable.TransitionDrawable

import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View

import androidx.appcompat.app.AppCompatActivity
import etud.univ.times_up.databinding.ActivityStartBinding



class StartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStartBinding

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        supportActionBar?.hide()
        super.onCreate(savedInstanceState)
        binding = ActivityStartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Use binding to access views
        binding.playButton.setOnTouchListener { _, event ->
            val transition = binding.playButton.drawable as TransitionDrawable
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    transition.startTransition(150)
                    playButtonSong(this)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    transition.reverseTransition(150)
                    val intent = Intent(this, GameSetup::class.java)
                    startActivity(intent)
                }
            }
            true
        }






    }

    override fun onDestroy() {
        val musicIntent = Intent(this, BackgroundMusicService::class.java)
        //stopService(musicIntent)
        Log.d("info","destroy")
        super.onDestroy()

    }


}



/*var isMusicPlaying = true

toggleMusicButton.setOnClickListener {
    if (isMusicPlaying) {
        stopService(Intent(this, BackgroundMusicService::class.java))
    } else {
        startService(Intent(this, BackgroundMusicService::class.java))
    }
    isMusicPlaying = !isMusicPlaying
}*/
