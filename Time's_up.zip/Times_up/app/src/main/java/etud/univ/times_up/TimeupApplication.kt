package etud.univ.times_up

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner

class TimeUpApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Ajouter un observateur global pour gérer la musique
        ProcessLifecycleOwner.get().lifecycle.addObserver(MusicLifecycleObserver(this))
    }
}