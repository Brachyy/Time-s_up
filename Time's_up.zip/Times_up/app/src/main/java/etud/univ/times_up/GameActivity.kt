package etud.univ.times_up

import android.content.res.AssetManager
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import etud.univ.times_up.databinding.ActivityGameBinding
import java.io.BufferedReader
import java.io.InputStreamReader

class GameActivity : AppCompatActivity() {
    private lateinit var binding: ActivityGameBinding

    private lateinit var fullWordList : List<String>

    // Fonction pour charger les mots depuis le fichier .txt dans les assets
    fun loadWordsFromAssets(assetManager: AssetManager): List<String> {
        val wordList = mutableListOf<String>()

        try {
            // Ouvre le fichier texte depuis les assets
            val inputStream = assetManager.open("liste_famille.txt") // Remplace par le nom de ton fichier
            val reader = BufferedReader(InputStreamReader(inputStream))

            // Lire chaque ligne du fichier et ajouter à la liste
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                wordList.add(line!!.trim())  // Ajouter le mot à la liste
            }

            reader.close()
        } catch (e: Exception) {
            Log.e("GameActivity", "Erreur lors du chargement du fichier", e)
        }

        return wordList
    }

    private lateinit var originalGameWordList: List<String>
    private var gameWordList: MutableList<String> = mutableListOf()
    private lateinit var currentWord:String


    private var currentTeamIndex = 0
    private var currentPlayerIndex = 0
    private var currentRoundCount: Int = 1

    private val timerDuration = 45000L // 3 secondes pour les tests
    private var countDownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initializeGame()

        binding.readyButton.setOnClickListener {
            startTurn()
        }

        binding.guessButton.setOnClickListener {
            wordGuessed()
        }

        binding.nextRoundButton.setOnClickListener {
            resetForNextRound()
        }
        binding.passedButton.setOnClickListener {
            gameWordList.add(gameWordList.size-1,currentWord)
            currentWord=gameWordList.first()
            gameWordList.remove(currentWord)
            binding.wordText.text=currentWord
            binding.wordText.requestLayout()
        }
    }

    private fun initializeGame() {
        fullWordList=loadWordsFromAssets(assets)
        originalGameWordList = fullWordList.shuffled().take(50)
        gameWordList = originalGameWordList.toMutableList()
        currentWord = gameWordList.first()
        gameWordList.remove(currentWord)

        updatePlayerTurnDisplay()
    }

    private fun startTurn() {
        binding.readyButton.visibility = View.GONE
        binding.playerTurnText.visibility = View.GONE
        binding.playerTurnSentence.visibility = View.GONE

        startCountdown()
        binding.wordText.text = currentWord
        binding.wordText.requestLayout()
        binding.wordText.visibility = View.VISIBLE
        binding.timerText.visibility = View.VISIBLE
        binding.guessButton.visibility = View.VISIBLE
        if(currentRoundCount==2){
            binding.passedButton.visibility = View.VISIBLE
        }
        binding.buttonContainer.visibility = View.VISIBLE
        binding.guessButton.isEnabled = true

    }

    private fun startCountdown() {
        countDownTimer?.cancel()
        countDownTimer = object : CountDownTimer(timerDuration, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                binding.timerText.text = "${millisUntilFinished / 1000}s"
            }

            override fun onFinish() {
                endTurn()
            }
        }.start()
    }

    private fun showNextWord() {
        // Si un mot est en attente (pas deviné), on l'affiche
        if(gameWordList.isNotEmpty()) {
            currentWord = gameWordList.first()
            gameWordList.remove(currentWord)
            binding.wordText.text = currentWord
            binding.wordText.requestLayout()
        }
        else{
            if(currentRoundCount == 3){
                totallyEndGame()
            }
            else {
                currentRoundCount++
                endGame()
            }
        }
    }





    private fun wordGuessed() {
        Log.d("GAME", "Mot deviné: ${binding.wordText.text.toString()}")
        val currentTeam = TeamManager.getTeams()[currentTeamIndex]
        currentTeam.score++
        showNextWord()  // Afficher le prochain mot
    }



    private fun endTurn() {
        playEndTimeSong(this)
        countDownTimer?.cancel()
        binding.wordText.text = ""
        binding.timerText.text = ""
        binding.readyButton.visibility = View.VISIBLE
        binding.readyButton.isEnabled = true
        binding.guessButton.visibility = View.GONE

        binding.playerTurnSentence.visibility = View.VISIBLE
        binding.buttonContainer.visibility = View.GONE

        binding.guessButton.isEnabled = false
        nextPlayer()
        updatePlayerTurnDisplay()
    }


    private fun nextPlayer() {
        val teams = TeamManager.getTeams()
        currentTeamIndex = (currentTeamIndex + 1) % teams.size
        if(currentTeamIndex==1)
            currentPlayerIndex++




    }

    private fun updatePlayerTurnDisplay() {
        val teams = TeamManager.getTeams()
        val currentTeam = teams[currentTeamIndex]
        val currentPlayer = currentTeam.players[currentPlayerIndex % currentTeam.players.size]
        Log.d("NONE", "Equipe actuelle : $currentTeamIndex, taille de l'equipe : ${currentTeam.players.size}, joueur : ${currentPlayerIndex % currentTeam.players.size}")


        binding.playerTurnText.text = "${currentPlayer.name.uppercase()}"
        binding.playerTurnText.visibility = View.VISIBLE
    }


    private fun endGame() {
        countDownTimer?.cancel()

        val sortedTeams = TeamManager.getTeams().sortedByDescending { it.score }
        val scoreDisplay = sortedTeams.joinToString("\n\n") { team ->
            val players = team.players.joinToString(", ") { it.name } // Liste des joueurs d'une équipe
            "${team.name} : ${team.score} points\nJoueurs : $players"
        }

        binding.scoreText.text = scoreDisplay
        binding.scoreContainer.visibility = View.VISIBLE
        binding.nextRoundButton.visibility = View.VISIBLE

        binding.wordText.visibility = View.GONE
        binding.timerText.visibility = View.GONE
        binding.readyButton.visibility = View.GONE
        binding.guessButton.visibility = View.GONE
        binding.passedButton.visibility = View.GONE
    }

    private fun resetForNextRound() {
        gameWordList = originalGameWordList.shuffled().toMutableList()
        currentWord = gameWordList.first()
        gameWordList.remove(currentWord)



        binding.scoreContainer.visibility = View.GONE
        binding.nextRoundButton.visibility = View.GONE
        binding.readyButton.visibility = View.VISIBLE
        binding.passedButton.visibility = View.GONE

        currentTeamIndex = 0
        currentPlayerIndex = 0
        updatePlayerTurnDisplay()
    }

    private fun totallyEndGame() {
        countDownTimer?.cancel()


        val sortedTeams = TeamManager.getTeams().sortedByDescending { it.score }
        val scoreDisplay = sortedTeams.joinToString("\n\n") { team ->
            val players = team.players.joinToString(", ") { it.name } // Liste des joueurs d'une équipe
            "${team.name} : ${team.score} points\nJoueurs : $players"
        }

        binding.scoreText.text = scoreDisplay
        binding.scoreContainer.visibility = View.VISIBLE
        binding.wordText.visibility = View.GONE
        binding.timerText.visibility = View.GONE
        binding.readyButton.visibility = View.GONE
        binding.guessButton.visibility = View.GONE
        binding.passedButton.visibility = View.GONE
    }
}
