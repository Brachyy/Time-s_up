package etud.univ.times_up
import android.media.MediaPlayer
import android.content.Context



     fun playButtonSong(context: Context) {
         // Nombre total de fichiers sons dans "raw"


         // Générer un nom aléatoire
         val soundName = "boutton_tu"

         // Obtenir l'ID de la ressource à partir de son nom
         val resourceId = context.resources.getIdentifier(soundName, "raw", context.packageName)
         // Vérifier que le fichier existe avant de jouer
         if (resourceId != 0) {
             val mediaPlayer = MediaPlayer.create(context, resourceId)
             mediaPlayer.setVolume(0.3f, 0.3f) // Volume à 50%
             mediaPlayer.start()
         } else {
             println("Sound file not found: $soundName")
         }

     }
fun playEndTimeSong(context: Context) {
    // Nombre total de fichiers sons dans "raw"


    // Générer un nom aléatoire
    val soundName = "end_time_song"

    // Obtenir l'ID de la ressource à partir de son nom
    val resourceId = context.resources.getIdentifier(soundName, "raw", context.packageName)
    // Vérifier que le fichier existe avant de jouer
    if (resourceId != 0) {
        val mediaPlayer = MediaPlayer.create(context, resourceId)
        mediaPlayer.setVolume(50f, 50f)
        mediaPlayer.start()
    } else {
        println("Sound file not found: $soundName")
    }
}
