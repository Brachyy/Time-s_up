package etud.univ.times_up

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder
import android.util.Log

class BackgroundMusicService : Service() {
    private lateinit var mediaPlayer: MediaPlayer

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Initialise le MediaPlayer avec une musique
        mediaPlayer = MediaPlayer.create(this, R.raw.background_music)
        mediaPlayer.isLooping = true // Boucle infinie
        mediaPlayer.setVolume(0.1f, 0.1f) // Volume à 50%
        mediaPlayer.start()
        Log.d("BackgroundMusicService", "Service démarré")

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        if (this::mediaPlayer.isInitialized) {
            mediaPlayer.stop()
            mediaPlayer.release()

        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null // Ce service ne prend pas en charge les liaisons
    }
}